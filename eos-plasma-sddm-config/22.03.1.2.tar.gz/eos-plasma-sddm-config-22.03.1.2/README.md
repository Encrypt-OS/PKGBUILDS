# eos-plasma-sddm-config
sddm dropin files for EncryptOS plasma installs
