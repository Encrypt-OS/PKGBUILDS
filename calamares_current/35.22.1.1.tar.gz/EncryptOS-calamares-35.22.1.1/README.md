# calamares extra-modules, installer-scripts, branding and module configuration file

[![Maintenance](https://img.shields.io/maintenance/yes/2022.svg)]()


# Calamares EncryptOS repository

used by the following PKGBUILD's:

1. Calamares package itself:

https://github.com/Encrypt-OS/PKGBUILDS/tree/main/calamares_current

2. EncryptOS specific configurations for default installs:

https://github.com/Encrypt-OS/PKGBUILDS/tree/main/calamares_config_default

