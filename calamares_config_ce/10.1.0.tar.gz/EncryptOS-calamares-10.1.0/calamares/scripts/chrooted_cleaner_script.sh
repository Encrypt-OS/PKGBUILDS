#!/usr/bin/env bash

# New version of cleaner_script
# Made by @fernandomaroto and @manuel 
# Any failed command will just be skipped, error message may pop up but won't crash the install process
# Net-install creates the file /tmp/run_once in live environment (need to be transfered to installed system) so it can be used to detect install option
# ISO-NEXT specific cleanup removals and additions (08-2021) @killajoe and @manuel
# 01-2022 passing in online and username as params - @dalto

_c_c_s_msg() {            # use this to provide all user messages (info, warning, error, ...)
    local type="$1"
    local msg="$2"
    echo "==> $type: $msg"
}

_pkg_msg() {            # use this to provide all package management messages (install, uninstall)
    local type="$1"
    local pkgs="$2"
    case "$type" in
        remove | uninstall) type="uninstalling" ;;
        install) type="installing" ;;
    esac
    echo "==> $type $pkgs"
}

# parse the options
for i in "$@"; do
    case $i in
        --user=*)
            NEW_USER="${i#*=}"
            shift
        ;;
        --online)
            INSTALL_TYPE="online"
            shift
        ;;
    esac
done


_check_internet_connection(){
    eos-connection-checker
}

_is_pkg_installed() {  # this is not meant for offline mode !?
    # returns 0 if given package name is installed, otherwise 1
    local pkgname="$1"
    pacman -Q "$pkgname" >& /dev/null
}

_remove_a_pkg() {
    local pkgname="$1"
    _pkg_msg remove "$pkgname"
    pacman -Rsn --noconfirm "$pkgname"
}

_remove_pkgs_if_installed() {  # this is not meant for offline mode !?
    # removes given package(s) and possible dependencies if the package(s) are currently installed
    local pkgname
    local removables=()
    for pkgname in "$@" ; do
        if _is_pkg_installed "$pkgname" ; then
            _pkg_msg remove "removing $pkgname"
            removables+=("$pkgname")
        fi
    done
    if [ -n "$removables" ] ; then
        pacman -Rsn --noconfirm "${removables[@]}"
    fi
}

_install_needed_packages() {
    if eos-connection-checker ; then
        _pkg_msg install "if missing: $*"
        pacman -S --needed --noconfirm "$@"
    else
        _c_c_s_msg warning "no internet connection, cannot install packages $*"
    fi
}


##################################################################
# Virtual machine stuff.
# For virtual machines we assume internet connection exists.
##################################################################

_virt_remove() {
    local pkg
    for pkg in "$@" ; do
        _pkg_msg remove "$pkg"
        pacman -Rns --noconfirm "$pkg"
    done
}

_vm_environment_set1() {
    local varname="$1"
    if [ -z "$(grep "^$varname=" /etc/environment)" ] ; then
        _c_c_s_msg info "adding $varname=1 to /etc/environment"
        echo "$varname=1" >> /etc/environment
    fi
}

_sway_in_vm_settings() {
    # Settings for sway in a virtual machine
    if [ -x /usr/bin/swaybg ] ; then
        # We are using sway here (see also: eos-script-lib-yad, eos_IsSway()).
        _vm_environment_set1 WLR_NO_HARDWARE_CURSORS
        case "$detected_vm" in
            qemu) _vm_environment_set1 WLR_RENDERER_ALLOW_SOFTWARE ;;
        esac
    fi
}

_virtual_machines() {
    local detected_vm="$1"
    local pkgs_common="xf86-video-vmware"
    local pkgs_remove_from_vm="power-profiles-daemon"
    local pkgs_vbox="virtualbox-guest-utils"
    local pkgs_qemu="qemu-guest-agent"
    local pkgs_vmware="open-vm-tools xf86-input-vmmouse"

    [ -n "$detected_vm" ] || detected_vm="$(device-info --vm)"

    case "$detected_vm" in               # 2021-Sep-30: device-info may output one of: "virtualbox", "qemu", "kvm", "vmware" or ""
        virtualbox)
            _c_c_s_msg info "VirtualBox VM detected."
            _virt_remove $pkgs_qemu $pkgs_vmware $pkgs_remove_from_vm
            _install_needed_packages $pkgs_vbox $pkgs_common
            _sway_in_vm_settings           # Note: sway requires enabling 3D support for the vbox virtual machine!
            ;;
        vmware)
            _c_c_s_msg info "VmWare VM detected."
            _virt_remove $pkgs_qemu $pkgs_vbox $pkgs_remove_from_vm
            _install_needed_packages $pkgs_vmware $pkgs_common
            _sway_in_vm_settings
            ;;
        qemu)
            # common pkgs ??
            _c_c_s_msg info "Qemu VM detected."
            _virt_remove $pkgs_vmware $pkgs_vbox $pkgs_common $pkgs_remove_from_vm
            _install_needed_packages $pkgs_qemu
            _sway_in_vm_settings
            ;;
        kvm)
            _c_c_s_msg info "Kvm VM detected."
            if [ -n "$(lspci -vnn | grep -iw "qemu virtual machine")" ] ; then
                $FUNCNAME qemu
            else
                 _virt_remove $pkgs_remove_from_vm
                _install_needed_packages $pkgs_qemu $pkgs_vbox $pkgs_common   # ???
                _sway_in_vm_settings
            fi
            ;;
        *)
            _c_c_s_msg info "VM not detected."
            _virt_remove $pkgs_vbox $pkgs_qemu $pkgs_vmware $pkgs_common
            ;;
    esac
}

_sed_stuff(){

    # Journal for offline. Turn volatile (for iso) into a real system.
    sed -i 's/volatile/auto/g' /etc/systemd/journald.conf 2>>/tmp/.errlog
    sed -i 's/.*pam_wheel\.so/#&/' /etc/pam.d/su
}

_clean_archiso(){

    local _files_to_remove=(                               
        /etc/sudoers.d/g_wheel
        /etc/ssh/sshd_config
        /var/lib/NetworkManager/NetworkManager.state
        /etc/systemd/system/getty@tty1.service.d/autologin.conf
        /etc/systemd/system/getty@tty1.service.d
        /etc/systemd/system/multi-user.target.wants/*
        /etc/systemd/journald.conf.d
        /etc/systemd/logind.conf.d
        /etc/mkinitcpio-archiso.conf
        /etc/initcpio
        /home/$NEW_USER/{.wget-hsts,.screenrc,.ICEauthority}
        /root/{.automated_script.sh,.zlogin,.xinitrc,.xprofile,.wget-hsts,.screenrc,.ICEauthority,set_once.sh,xed.dconf}
        /root/.config/{qt5ct,Kvantum,dconf}
        /etc/motd
        /{gpg.conf,gpg-agent.conf,pubring.gpg,secring.gpg}
        /version
    )

    local xx

    for xx in ${_files_to_remove[*]}; do rm -rf $xx; done

    find /usr/lib/initcpio -name archiso* -type f -exec rm '{}' \;

}

_clean_offline_packages(){

    local _packages_to_remove=( 
    gparted
    grsync
    calamares_current
    calamares_config_default
    calamares_config_ce
    edk2-shell
    boost-libs
    doxygen
    expect
    gpart
    tcpdump
    libpwquality
    refind
    rate-mirrors
    kvantum
    polkit-qt5
    qt5-declarative
    qt5-webchannel
    qt5-webengine
    qt6-base
    sonnet
    kwidgetsaddons
    kitemviews
    kguiaddons
    kdbusaddons
    kcoreaddons
    karchive
    ki18n
    qt5ct
    arch-install-scripts
    squashfs-tools
    extra-cmake-modules 
    cmake
    elinks
    yaml-cpp
    syslinux
    clonezilla
    ckbcomp
    xcompmgr
    memtest86+
    mkinitcpio-archiso
    blueberry
    )

    # @ does one by one to avoid errors in the entire process
    # * can be used to treat all packages in one command
    # for xx in ${_packages_to_remove[@]}; do pacman -Rsc $xx --noconfirm; done

    local xx

    for xx in "${_packages_to_remove[@]}" ; do
        pacman -Rsc --noconfirm "$xx"
    done
}

_EncryptOS(){
    [ -r /root/.bash_profile ] && sed -i "/if/,/fi/"'s/^/#/' /root/.bash_profile
    sed -i "/if/,/fi/"'s/^/#/' /home/$NEW_USER/.bash_profile
}

_is_offline_mode() {
    if [ "$INSTALL_TYPE" = "online" ] ; then
        return 1           # online install mode
    else
        return 0           # offline install mode
    fi
}
_is_online_mode() { ! _is_offline_mode ; }


_check_install_mode(){

    if _is_online_mode ; then
        local INSTALL_OPTION="ONLINE_MODE"
    else
        local INSTALL_OPTION="OFFLINE_MODE"
    fi

    case "$INSTALL_OPTION" in
        OFFLINE_MODE)
                _clean_archiso
                chown $NEW_USER:$NEW_USER /home/$NEW_USER/.bashrc
                _sed_stuff
                _clean_offline_packages
            ;;

        ONLINE_MODE)
                # not implemented yet. For now run functions at "SCRIPT STARTS HERE"
                :
                # all systemd are enabled - can be specific offline/online in the future
            ;;
        *)
            ;;
    esac
}

_remove_ucode(){
    local ucode="$1"
    _remove_a_pkg "$ucode"
}

_remove_other_graphics_drivers() {
    local graphics="$(device-info --vga ; device-info --display)"
    local amd=no

    # remove Intel graphics driver if it is not needed
    if [ -z "$(echo "$graphics" | grep "Intel Corporation")" ] ; then
        _remove_a_pkg xf86-video-intel
    fi

    # remove AMD graphics driver if it is not needed
    if [ -n "$(echo "$graphics" | grep "Advanced Micro Devices")" ] ; then
        amd=yes
    elif [ -n "$(echo "$graphics" | grep "AMD/ATI")" ] ; then
        amd=yes
    elif [ -n "$(echo "$graphics" | grep "Radeon")" ] ; then
        amd=yes
    fi
    if [ "$amd" = "no" ] ; then
        _remove_a_pkg xf86-video-amdgpu
        _remove_a_pkg xf86-video-ati
    fi
}

_remove_broadcom_wifi_driver_old() {
    local pkgname=broadcom-wl-dkms
    local wifi_pci
    local wifi_driver

    # _is_pkg_installed $pkgname && {
        wifi_pci="$(lspci -k | grep -A4 " Network controller: ")"
        if [ -n "$(lsusb | grep " Broadcom ")" ] || [ -n "$(echo "$wifi_pci" | grep " Broadcom ")" ] ; then
            return
        fi
        wifi_driver="$(echo "$wifi_pci" | grep "Kernel driver in use")"
        if [ -n "$(echo "$wifi_driver" | grep "in use: wl$")" ] ; then
            return
        fi
        _remove_a_pkg $pkgname
    # }
}

_remove_broadcom_wifi_driver() {
    local pkgname=broadcom-wl-dkms
    local file=/tmp/$pkgname.txt
    if [ "$(cat $file 2>/dev/null)" = "no" ] ; then
        _remove_a_pkg $pkgname
    fi
}

_install_extra_drivers_to_target() {
    # Install special drivers to target if needed.
    # The drivers exist on the ISO and were copied to the target.

    local dir=/opt/extra-drivers
    local pkg

    # Handle the r8168 package.
    if [ -r /tmp/r8168_in_use ] ; then
        # We must install r8168 now.
        if _is_offline_mode ; then
            # Install using the copied r8168 package.
            pkg="$(/usr/bin/ls -1 $dir/r8168-*-x86_64.pkg.tar.zst)"
            if [ -n "$pkg" ] ; then
                _pkg_msg install "r8168 (offline)"
                pacman -U --noconfirm $pkg
            else
                _c_c_s_msg error "no r8168 package in folder $dir!"
            fi
        else
            # Install r8168 package from the mirrors.
            _install_needed_packages r8168
        fi
    fi
}

_nvidia_remove() {
    _pkg_msg remove "$*"
    pacman -Rsc --noconfirm "$@"
}

_remove_nvidia_drivers() {
    local remove="pacman -Rsc --noconfirm"

    if _is_offline_mode ; then
        # delete packages separately to avoid all failing if one fails
        _nvidia_remove nvidia-dkms
        _nvidia_remove nvidia-utils
        _nvidia_remove nvidia-settings
        _nvidia_remove nvidia-installer-dkms
    fi
}

_manage_nvidia_packages() {
    local file=/tmp/nvidia-info.bash        # nvidia info from livesession
    local nvidia_card=""                    # these two variables are defined in $file
    local nvidia_driver=""

    if [ ! -r $file ] ; then
        _c_c_s_msg warning "file $file does not exist!"
        _remove_nvidia_drivers
    else
        source $file
        if [ "$nvidia_driver" = "no" ] ; then
            _remove_nvidia_drivers
        elif [ "$nvidia_card" = "yes" ] ; then
            _install_needed_packages nvidia-installer-dkms nvidia-dkms
            nvidia-installer-kernel-para
        fi
    fi
}

_run_if_exists_or_complain() {
    local app="$1"

    if (which "$app" >& /dev/null) ; then
        _c_c_s_msg info "running $*"
        "$@"
    else
        _c_c_s_msg warning "program $app not found."
    fi
}

_fix_grub_stuff() {
    _run_if_exists_or_complain eos-hooks-runner
    _run_if_exists_or_complain eos-grub-fix-initrd-generation
}

_RunUserCommands() {
    local usercmdfile=/tmp/user_commands.bash
    if [ -r $usercmdfile ] ; then
        _c_c_s_msg info "running script $(basename $usercmdfile)"
        bash $usercmdfile $NEW_USER
    fi
}

_misc_cleanups() {
    # /etc/resolv.conf.pacnew may be unnecessary, so delete it

    local file=/etc/resolv.conf.pacnew
    if [ -z "$(grep -Pv "^[ ]*#" $file 2>/dev/null)" ] ; then
        _c_c_s_msg info "removing file $file"
        rm -f $file                                            # pacnew contains only comments
    fi
}

_clean_up(){
    local xx

    # Remove the "wrong" microcode.
    if [ -x /usr/bin/device-info ] ; then
        case "$(/usr/bin/device-info --cpu)" in
            GenuineIntel)       _remove_ucode amd-ucode ;;
            AuthenticAMD | *)   _remove_ucode intel-ucode ;;
        esac
    fi

    # install or remove nvidia graphics stuff
    _manage_nvidia_packages

    # remove AMD and Intel graphics drivers if they are not needed
    _remove_other_graphics_drivers

    # remove broadcom-wl-dkms if it is not needed
    _remove_broadcom_wifi_driver

    _install_extra_drivers_to_target

    _misc_cleanups

    # on the target, select file server based on country
    xx=/usr/bin/eos-select-file-server
    if [ -x $xx ] ; then
        _c_c_s_msg info "running $xx"
        local fileserver="$($xx)"
        if [ "$fileserver" != "gitlab" ] ; then
            _c_c_s_msg info "file server configured to '$fileserver'"
        fi
    else
        _c_c_s_msg warning "program $xx was not found"
    fi

    # enable TRIM systemd service
    # systemctl enable fstrim.timer # testing calamares services-systemd module calamares 3.2.45 update

    # run possible user-given commands
    _RunUserCommands

    # Fix various grub stuff.
    _fix_grub_stuff
}

_desktop_i3(){
    # i3 configs here
    # Note: variable 'desktop' from '_another_case' is visible here too!

    if ! _check_internet_connection ; then
        _c_c_s_msg warning "cannot fetch i3 configs, no connection."
        return
    fi

    git clone $(eos-github2gitlab https://github.com/EncryptOS-team/EncryptOS-i3wm-setup.git)
    pushd EncryptOS-i3wm-setup >/dev/null
    cp -R .config ~/
    cp -R .config /home/$NEW_USER/                                                
    chmod -R +x ~/.config/i3/scripts /home/$NEW_USER/.config/i3/scripts
    cp set_once.sh  ~/
    cp set_once.sh  /home/$NEW_USER/
    chmod +x ~/set_once.sh /home/$NEW_USER/set_once.sh
    cp .Xresources ~/
    cp .Xresources /home/$NEW_USER/
    cp .gtkrc-2.0 ~/
    cp .gtkrc-2.0 /home/$NEW_USER/
    cp .nanorc ~/
    cp .nanorc /home/$NEW_USER/
    cp xed.dconf ~/
    cp xed.dconf /home/$NEW_USER/
    chown -R $NEW_USER:$NEW_USER /home/$NEW_USER/
    popd >/dev/null
    rm -rf EncryptOS-i3wm-setup
}

_de_wm_config(){
    local desktops_lowercase="$(ls -1 /usr/share/xsessions/*.desktop 2>/dev/null | tr '[:upper:]' '[:lower:]' | sed -e 's|\.desktop$||' -e 's|^/usr/share/xsessions/||')"
    local desktop
    local i3_added=no # break for loop

    for desktop in $desktops_lowercase ; do
        case "$desktop" in
            i3*)
                if [ "$i3_added" = "no" ] ; then
                    i3_added=yes
                    _desktop_i3 
                fi
                ;;
        esac
    done
}

_setup_personal() {
    local file=/tmp/setup.sh
    local tmpdir
    if [ -r $file ] ; then
        # setup.sh was found, so run it
        tmpdir=$(mktemp -d)     # $tmpdir refers to a unique folder under /tmp
        pushd $tmpdir >/dev/null
        sh $file
        popd >/dev/null
        rm -rf $tmpdir
    else
        _c_c_s_msg info "$FUNCNAME: $file not found." >&2
    fi
}

_change_config_options(){
    #set lightdm.conf to logind-check-graphical=true
    sed -i 's?#logind-check-graphical=false?logind-check-graphical=true?' /etc/lightdm/lightdm.conf
    sed -i 's?#greeter-session=example-gtk-gnome?greeter-session=lightdm-slick-greeter?' /etc/lightdm/lightdm.conf
    sed -i 's?#allow-user-switching=true?allow-user-switching=true?' /etc/lightdm/lightdm.conf
}

_remove_gnome_software(){
    _remove_a_pkg gnome-software
}
_remove_discover(){
    _remove_a_pkg discover
}

_run_hotfix_end() {
    local file=hotfix-end.bash
    local type=""
    if ! _check_internet_connection ; then
        _is_offline_mode && type=info || type=warning
        _c_c_s_msg $type "cannot fetch $file, no connection."
        return
    fi
    local url=$(eos-github2gitlab https://raw.githubusercontent.com/EncryptOS-team/ISO-hotfixes/main/$file)
    wget --timeout=60 -q -O /tmp/$file $url && {
        _c_c_s_msg info "running script $file"
        bash /tmp/$file
    }
}

########################################
########## SCRIPT STARTS HERE ##########
########################################

_check_install_mode
_EncryptOS
_virtual_machines
#_change_config_options
#_remove_gnome_software
#_remove_discover
#_de_wm_config
#_setup_personal
_clean_up
_run_hotfix_end

rm -rf /etc/calamares /opt/extra-drivers
