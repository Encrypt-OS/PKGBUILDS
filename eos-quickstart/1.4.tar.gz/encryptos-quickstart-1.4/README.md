# EncryptOS Quickstart Installer

This is a simple tool to help an end-user get started by providing an easy way to install an application from a set of curated applications configured by default.
